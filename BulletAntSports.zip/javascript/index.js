window.onload = rotate;

var siteImages = new Array("./images/3packfishstrike.jpg","./images/fishstrikeIMG1.jpg","./images/fishstrikeIMG2.jpg");
var thisImage = 0;

function rotate() 
{
	thisImage++;
	
	if (thisImage == siteImages.length) 
	{
		thisImage = 0;
	}
	
	document.getElementById("rotatingBanner").src = siteImages[thisImage];

	
	setTimeout("rotate()", 3 * 1000);
}

function openNav() 
{
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}


function closeNav() 
{
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft = "0";
}